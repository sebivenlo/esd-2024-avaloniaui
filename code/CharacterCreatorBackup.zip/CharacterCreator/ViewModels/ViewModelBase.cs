﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace CharacterCreator.ViewModels;

public class ViewModelBase : ObservableObject
{
}
